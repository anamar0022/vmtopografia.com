// Service worker: guarda o site para funcionar sem rede.
// Ficheiros do site: primeiro a rede (para ver sempre a versão mais recente), cache se não houver rede.
var VERSAO = 'vmt-v2';
var BASE = ['./', 'app.js', 'manifest.webmanifest', 'favicon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'fonts/figtree.woff2', 'fonts/montserrat.woff2'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSAO).then(function (c) { return c.addAll(BASE); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (nomes) {
    return Promise.all(nomes.filter(function (n) { return n !== VERSAO; }).map(function (n) { return caches.delete(n); }));
  }).then(function () { return self.clients.claim(); }));
});

function guardar(pedido, resposta) {
  if (resposta && (resposta.ok || resposta.type === 'opaque')) {
    var copia = resposta.clone();
    caches.open(VERSAO).then(function (c) { c.put(pedido, copia); });
  }
  return resposta;
}

self.addEventListener('fetch', function (e) {
  var pedido = e.request;
  if (pedido.method !== 'GET') return;
  var url = new URL(pedido.url);

  if (url.origin !== self.location.origin) return;

  e.respondWith(
    fetch(pedido).then(function (res) { return guardar(pedido, res); }).catch(function () {
      return caches.match(pedido, { ignoreSearch: true }).then(function (r) {
        if (r) return r;
        if (pedido.mode === 'navigate') return caches.match('./');
        return Response.error();
      });
    })
  );
});
