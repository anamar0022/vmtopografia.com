'use strict';
// ---- Simulador ----
var PRECO_KM = 0.50;
var ESCALOES = [[2000, 300], [4000, 400], [6000, 600], [10000, 800]];
var LOCAIS = [["A dos Cunhados",39.152,-9.297],["A dos Francos",39.323,-9.047],["Abrantes",39.467,-8.2],["Abraveses",40.681,-7.921],["Abrigada",39.144,-9.019],["Adaúfe",41.587,-8.398],["Água Longa",41.25,-8.493],["Aguada de Cima",40.523,-8.427],["Águas Santas",41.21,-8.576],["Aguçadoura",41.431,-8.778],["Águeda",40.577,-8.444],["Aguiar da Beira",40.817,-7.544],["Alagoa",39.361,-7.539],["Alandroal",38.702,-7.403],["Albergaria-a-Velha",40.693,-8.48],["Albufeira",37.088,-8.25],["Alcabideche",38.734,-9.409],["Alcácer do Sal",38.373,-8.514],["Alcains",39.916,-7.457],["Alcanede",39.415,-8.822],["Alcanena",39.459,-8.669],["Alcanhões",39.296,-8.658],["Alcantarilha",37.13,-8.346],["Alcobaça",39.552,-8.977],["Alcochete",38.755,-8.961],["Alcoentre",39.209,-8.96],["Alcoutim",37.474,-7.472],["Aldeia de Joanes",40.139,-7.517],["Aldeia de Paio Pires",38.617,-9.083],["Aldeia Nova de São Bento",37.926,-7.408],["Alegrete",39.24,-7.323],["Alenquer",39.053,-9.009],["Alfândega da Fé",41.343,-6.961],["Alfarelos",40.151,-8.653],["Alfeizerão",39.5,-9.103],["Alfena",41.237,-8.525],["Alferrarede",39.483,-8.167],["Alfragide",38.732,-9.219],["Algés",38.702,-9.229],["Algoz",37.163,-8.304],["Algueirão",38.798,-9.344],["Alhadas",40.186,-8.791],["Alhandra",38.927,-9.009],["Alhos Vedros",38.655,-9.024],["Alijó",41.276,-7.475],["Aljezur",37.317,-8.801],["Aljubarrota",39.567,-8.929],["Aljustrel",37.878,-8.165],["Almada",38.679,-9.157],["Almancil",37.087,-8.031],["Almargem",38.845,-9.273],["Almeirim",39.208,-8.626],["Almodôvar",37.513,-8.06],["Almograve",37.657,-8.792],["Alpendurada",41.089,-8.246],["Alpiarça",39.257,-8.582],["Alter do Chão",39.197,-7.659],["Altura",37.176,-7.501],["Alvaiázere",39.823,-8.38],["Alvalade",38.753,-9.144],["Alvito",38.256,-7.992],["Alvor",37.13,-8.592],["Alvorninha",39.382,-9.037],["Amadora",38.754,-9.231],["Amarante",41.273,-8.082],["Amares",41.631,-8.351],["Amiães de Baixo",39.443,-8.734],["Amor",39.804,-8.86],["Amora",38.63,-9.116],["Amorim",41.405,-8.75],["Anadia",40.438,-8.434],["Ançã",40.272,-8.521],["Ansião",39.912,-8.436],["Anta",41.266,-8.628],["Apelação",38.814,-9.132],["Apúlia",41.485,-8.764],["Apúlia e Fão",41.512,-8.773],["Aradas",40.621,-8.642],["Arazede",40.286,-8.65],["Arcos",41.522,-8.422],["Arcos de Valdevez",41.847,-8.419],["Arcozelo",41.062,-8.632],["Areosa",41.718,-8.857],["Arganil",40.218,-8.054],["Argivai",41.377,-8.73],["Argoncilhe",41.025,-8.539],["Armação de Pêra",37.103,-8.357],["Armamar",41.108,-7.691],["Arões",41.456,-8.214],["Arouca",40.931,-8.245],["Arraiolos",38.724,-7.985],["Arranhó",38.954,-9.135],["Arrentela",38.625,-9.102],["Arrifana",40.916,-8.497],["Arronches",39.122,-7.286],["Arruda dos Vinhos",38.984,-9.077],["Árvore",41.339,-8.718],["Assafarge",40.159,-8.432],["Atalaia",39.456,-7.873],["Atouguia da Baleia",39.338,-9.326],["Avanca",40.808,-8.572],["Aveiras de Cima",39.138,-8.899],["Aveiro",40.644,-8.646],["Aveleda",41.521,-8.467],["Aver-o-Mar",41.406,-8.78],["Aves",41.37,-8.41],["Avintes",41.107,-8.551],["Avis",39.054,-7.892],["Azambuja",39.07,-8.868],["Azeitão",38.519,-9.014],["Azenha",41.077,-8.625],["Azinhaga",39.349,-8.53],["Baguim do Monte",41.192,-8.541],["Baião",41.163,-8.035],["Balazar",41.404,-8.624],["Baltar",41.193,-8.388],["Barcarena",38.732,-9.28],["Barcelos",41.532,-8.618],["Barqueiros",41.491,-8.732],["Barrancos",38.134,-6.976],["Barreiro",38.663,-9.072],["Barrosas",41.355,-8.299],["Batalha",39.66,-8.825],["Beato António",38.733,-9.103],["Beduido",40.764,-8.561],["Beiriz de Baixo",41.397,-8.724],["Beja",38.015,-7.863],["Belas",38.777,-9.264],["Belmonte",40.359,-7.349],["Belver",41.247,-7.276],["Bemfica",39.143,-8.687],["Benavente",38.979,-8.808],["Benedita",39.425,-8.97],["Benfica",38.751,-9.203],["Bensafrim",37.156,-8.735],["Beringel",38.057,-7.984],["Boavista dos Pinheiros",37.581,-8.664],["Bobadela",38.808,-9.099],["Boliqueime",37.137,-8.158],["Bombarral",39.267,-9.158],["Borba",38.806,-7.455],["Boticas",41.689,-7.669],["Bougado",41.34,-8.552],["Braga",41.55,-8.42],["Bragança",41.806,-6.757],["Branca",40.767,-8.483],["Brito",41.458,-8.361],["Buarcos",40.166,-8.877],["Bucelas",38.902,-9.119],["Cabanas de Tavira",37.135,-7.6],["Cabanas de Torres",39.156,-9.066],["Cabanas de Viriato",40.477,-7.974],["Cabeça Gorda",37.924,-7.793],["Cabeceiras de Basto",41.514,-7.989],["Cacém",38.767,-9.298],["Cacilhas",38.686,-9.149],["Cadafais",39.005,-9.004],["Cadaval",39.243,-9.103],["Caldas da Rainha",39.403,-9.138],["Caldas das Taipas",41.485,-8.348],["Caldas de Vizela",41.382,-8.309],["Caldelas",41.671,-8.381],["Calendário",41.404,-8.53],["Camarate",38.804,-9.128],["Campelos",39.197,-9.235],["Campo",41.185,-8.465],["Campo de Besteiros",40.557,-8.134],["Campo Maior",39.018,-7.065],["Canas de Senhorim",40.5,-7.899],["Candoso",41.428,-8.322],["Caneças",38.813,-9.227],["Canelas",41.083,-8.6],["Canidelo",41.123,-8.647],["Cantanhede",40.347,-8.594],["Caparica",38.662,-9.2],["Caranguejeira",39.746,-8.707],["Carapinheira",40.206,-8.648],["Carcavelos",38.691,-9.322],["Carnaxide",38.727,-9.247],["Carrazeda de Anciães",41.242,-7.307],["Carregado",39.024,-8.977],["Carregal do Sal",40.433,-8],["Cartaxo",39.16,-8.787],["Carvalhosa",41.301,-8.361],["Carvoeiro",37.097,-8.468],["Cascais",38.697,-9.421],["Castanheira de Pêra",40.007,-8.21],["Castanheira do Ribatejo",38.993,-8.973],["Castelo Branco",39.822,-7.491],["Castelo de Paiva",41.063,-8.265],["Castelo de Vide",39.416,-7.457],["Castelões de Cepeda",41.203,-8.335],["Castro Daire",40.898,-7.934],["Castro Marim",37.221,-7.444],["Castro Verde",37.698,-8.086],["Caxias",38.703,-9.277],["Cela",39.541,-9.034],["Celorico da Beira",40.637,-7.39],["Celorico de Basto",41.387,-8.001],["Cercal",37.801,-8.674],["Charneca",38.784,-9.143],["Charneca de Caparica",38.62,-9.194],["Chavão",41.452,-8.602],["Chaves",41.74,-7.469],["Cinfães",41.072,-8.09],["Coimbra",40.206,-8.42],["Colares",38.799,-9.447],["Comporta",38.381,-8.786],["Conceição",37.148,-7.604],["Condeixa-a-Nova",40.113,-8.498],["Constância",39.478,-8.336],["Corroios",38.64,-9.151],["Cortegaça",40.949,-8.621],["Coruche",38.96,-8.525],["Costa de Caparica",38.645,-9.236],["Covilhã",40.281,-7.505],["Cristelo",41.48,-8.698],["Cuba",38.165,-7.892],["Cucujães",40.874,-8.507],["Custoias",41.105,-7.321],["Darque",41.683,-8.767],["Eixo",40.628,-8.569],["Elvas",38.882,-7.163],["Entroncamento",39.467,-8.467],["Ericeira",38.963,-9.416],["Ermesinde",41.217,-8.553],["Ervedosa do Douro",41.166,-7.473],["Esgueira",40.649,-8.629],["Esmoriz",40.958,-8.628],["Espargo",40.925,-8.575],["Espinho",41.008,-8.641],["Esporões",41.51,-8.417],["Esposende",41.536,-8.782],["Estarreja",40.756,-8.572],["Estela",41.449,-8.752],["Estói",37.095,-7.894],["Estômbar",37.146,-8.485],["Estoril",38.706,-9.398],["Estremoz",38.844,-7.586],["Évora",38.567,-7.9],["Fafe",41.451,-8.173],["Famalicão",39.536,-9.083],["Famões",38.788,-9.21],["Fânzeres",41.168,-8.53],["Faria",41.483,-8.672],["Faro",37.019,-7.927],["Fátima",39.621,-8.652],["Favaios",41.269,-7.505],["Fazendas de Almeirim",39.176,-8.569],["Feira",40.925,-8.543],["Felgueiras",41.368,-8.194],["Ferragudo",37.125,-8.519],["Ferreira",41.267,-8.344],["Ferreira do Alentejo",38.05,-8.033],["Ferreira do Zêzere",39.694,-8.292],["Ferreiras",37.129,-8.238],["Ferreiros",41.631,-8.364],["Ferrel",39.364,-9.315],["Fiães",40.994,-8.525],["Figueira da Foz",40.151,-8.862],["Figueira de Castelo Rodrigo",40.893,-6.963],["Figueiró",41.299,-8.168],["Figueiró dos Vinhos",39.904,-8.275],["Fontanelas",38.848,-9.439],["Fornos de Algodres",40.628,-7.541],["Fortios",39.325,-7.501],["Foz do Arelho",39.437,-9.214],["Foz do Douro",41.151,-8.671],["Foz do Sousa",41.097,-8.502],["Fradelos",41.368,-8.599],["Frazão",41.259,-8.4],["Freamunde",41.288,-8.335],["Freixo de Espada à Cinta",41.09,-6.806],["Fronteira",39.056,-7.649],["Frossos",41.566,-8.451],["Fundão",40.14,-7.501],["Fuzeta",37.054,-7.747],["Gafanha da Encarnação",40.618,-8.733],["Gafanha da Nazaré",40.636,-8.713],["Galegos",41.563,-8.572],["Gandra",41.522,-8.762],["Gavião",39.464,-7.934],["Gemunde",41.268,-8.645],["Godim",41.171,-7.803],["Góis",40.157,-8.11],["Golegã",39.405,-8.486],["Gondizalves",41.542,-8.456],["Gondomar",41.145,-8.532],["Grândola",38.177,-8.567],["Grijó",41.028,-8.58],["Guarda",40.537,-7.266],["Gueral",41.459,-8.629],["Guia",37.13,-8.3],["Guifões",41.197,-8.669],["Guimarães",41.444,-8.296],["Guisande",41.483,-8.446],["Gulpilhares",41.083,-8.627],["Idanha-a-Nova",39.923,-7.241],["Ílhavo",40.602,-8.67],["Joane",41.439,-8.408],["Jovim",41.111,-8.519],["Lago",41.621,-8.413],["Lagoa",37.135,-8.453],["Lagos",37.102,-8.674],["Lamas",40.986,-8.569],["Lamego",41.097,-7.81],["Laranjeira",38.656,-9.154],["Laranjeiro",37.068,-7.808],["Lavos",40.094,-8.828],["Lavra",41.259,-8.718],["Lavradio",38.668,-9.052],["Leça da Palmeira",41.191,-8.7],["Leça do Bailio",41.212,-8.634],["Leiria",39.744,-8.807],["Linda-a-Velha",38.714,-9.242],["Lisboa",38.717,-9.133],["Lobão",40.987,-8.486],["Lordelo",41.374,-8.38],["Loriga",40.325,-7.69],["Lorvão",40.259,-8.317],["Loulé",37.138,-8.02],["Loures",38.831,-9.168],["Louriçal",40.004,-8.737],["Lourinhã",39.242,-9.313],["Lourosa",40.984,-8.551],["Lousã",40.117,-8.249],["Lousada",41.278,-8.28],["Luso",40.384,-8.378],["Lustosa",41.341,-8.317],["Luz",37.092,-7.704],["Mação",39.556,-7.994],["Macedo de Cavaleiros",41.538,-6.961],["Maceira",39.689,-8.894],["Macieira de Cambra",40.859,-8.373],["Macieira de Rates",41.441,-8.634],["Madalena",39.571,-8.446],["Mafra",38.938,-9.328],["Maia",41.236,-8.62],["Malveira",38.932,-9.258],["Mangualde",40.604,-7.761],["Manta Rota",37.168,-7.518],["Manteigas",40.403,-7.54],["Marco de Canavezes",41.184,-8.149],["Margaride",41.365,-8.2],["Marinha Grande",39.748,-8.932],["Marinhais",39.047,-8.702],["Marinhas",41.559,-8.783],["Mariz",41.528,-8.671],["Marmelete",37.31,-8.668],["Marvão",39.394,-7.377],["Massamá",38.753,-9.281],["Matosinhos",41.182,-8.689],["Meadela",41.707,-8.796],["Mealhada",40.378,-8.45],["Meca",39.082,-9.035],["Mêda",40.966,-7.262],["Meinedo",41.248,-8.258],["Melres",41.07,-8.401],["Mem Martins",38.794,-9.343],["Merelim",41.586,-8.466],["Mértola",37.643,-7.661],["Mesão Frio",41.16,-7.89],["Mexilhoeira Grande",37.159,-8.615],["Milharado",38.947,-9.199],["Milheirós",41.215,-8.588],["Milheirós de Poiares",40.922,-8.468],["Minas de São Domingos",37.673,-7.498],["Minde",39.516,-8.688],["Mindelo",41.315,-8.721],["Mira",39.543,-8.715],["Miranda do Corvo",40.093,-8.333],["Miranda do Douro",41.497,-6.273],["Mirandela",41.487,-7.187],["Mogadouro",41.34,-6.712],["Moimenta da Beira",40.984,-7.618],["Moita",38.651,-8.99],["Moita dos Ferreiros",39.248,-9.224],["Monção",42.079,-8.481],["Moncarapacho",37.084,-7.788],["Monchique",37.318,-8.555],["Mondim de Basto",41.412,-7.954],["Monforte",39.053,-7.437],["Monsanto",39.462,-8.712],["Montalegre",41.824,-7.79],["Montalvinho",39.483,-8.3],["Montalvo",39.483,-8.3],["Montargil",39.078,-8.17],["Monte Estoril",38.706,-9.406],["Monte Gordo",37.182,-7.452],["Monte Real",39.852,-8.863],["Monte Redondo",39.899,-8.832],["Montemor-o-Novo",38.648,-8.215],["Montemor-o-Velho",40.173,-8.686],["Montijo",38.707,-8.974],["Mora",38.944,-8.164],["Moreira",41.248,-8.648],["Moreira de Conegos",41.387,-8.339],["Mortágua",40.397,-8.232],["Moscavide e Portela",38.779,-9.102],["Mosteirô",40.898,-8.532],["Moura",38.14,-7.449],["Mourão",38.384,-7.342],["Mozelos",41.868,-8.398],["Murça",41.406,-7.455],["Murtosa",40.737,-8.638],["Nadadouro",39.419,-9.191],["Nazaré",39.603,-9.068],["Negreiros",41.436,-8.614],["Negrelos",41.349,-8.401],["Nelas",40.532,-7.852],["Neves",38.023,-7.813],["Nisa",39.515,-7.649],["Nogueira",41.242,-8.587],["Nogueira da Regedoura",41.005,-8.592],["Óbidos",39.361,-9.157],["Odemira",37.598,-8.64],["Odivelas",38.793,-9.184],["Oeiras",38.691,-9.311],["Oiã",40.543,-8.539],["Oleiros",39.919,-7.914],["Olhão",37.029,-7.841],["Olhos de Água",37.09,-8.192],["Olivais",38.77,-9.107],["Olival",41.05,-8.544],["Olival do Basto",38.791,-9.166],["Oliveira",41.478,-8.47],["Oliveira de Azemeis",40.841,-8.476],["Oliveira de Frades",40.734,-8.175],["Oliveira do Bairro",40.515,-8.494],["Oliveira do Douro",41.125,-8.585],["Oliveira do Hospital",40.362,-7.86],["Oliveira do Mondego",40.323,-8.224],["Oliveirinha",40.607,-8.592],["Ota",39.112,-8.991],["Ourém",39.642,-8.592],["Ourique",37.654,-8.226],["Ovar",40.859,-8.625],["Paço de Arcos",38.696,-9.291],["Paços de Brandão",40.975,-8.584],["Paços de Ferreira",41.277,-8.376],["Paderne",37.179,-8.201],["Paialvo",39.564,-8.468],["Palmela",38.569,-8.901],["Pampilhosa da Serra",40.046,-7.952],["Pampilhosa do Botão",40.336,-8.427],["Parchal",37.138,-8.517],["Pardilhó",40.799,-8.626],["Parede",38.693,-9.354],["Paredes",41.205,-8.331],["Paredes de Coura",41.91,-8.561],["Pataias",39.67,-8.996],["Pedrógão Grande",39.918,-8.146],["Pedroso",41.411,-8.749],["Pedrouços",41.189,-8.586],["Pego",39.461,-8.15],["Penacova",40.269,-8.282],["Penafiel",41.208,-8.283],["Penamacor",40.169,-7.17],["Penedo Gordo",37.985,-7.917],["Penedono",40.989,-7.394],["Penela",40.033,-8.383],["Peniche",39.356,-9.381],["Pêra",37.123,-8.341],["Perafita",41.183,-8.255],["Perelhal",41.531,-8.69],["Pero Pinheiro",38.858,-9.324],["Perozinho",41.065,-8.585],["Peso da Régua",41.163,-7.789],["Piedade",38.67,-9.159],["Pinhal Novo",38.631,-8.914],["Pinheiro Grande",39.392,-8.434],["Pinhel",40.774,-7.067],["Poceirão",38.831,-8.794],["Poiares",40.21,-8.257],["Pombal",39.917,-8.628],["Ponte",41.471,-8.33],["Ponte da Barca",41.805,-8.416],["Ponte de Lima",41.767,-8.584],["Ponte de Sôr",39.25,-8.01],["Pontével",39.149,-8.839],["Pontinha",38.768,-9.199],["Porches",37.127,-8.402],["Portalegre",39.294,-7.431],["Portel",38.307,-7.702],["Portimão",37.139,-8.538],["Porto",41.15,-8.611],["Porto Covo",37.853,-8.79],["Porto de Mós",39.602,-8.818],["Porto Salvo",38.723,-9.305],["Póvoa de Lanhoso",41.576,-8.27],["Póvoa de Santa Iria",38.861,-9.065],["Póvoa de Santo Adrião",38.8,-9.167],["Póvoa de Varzim",41.383,-8.764],["Póvoa e Meadas",39.51,-7.518],["Prado",41.602,-8.463],["Pragal",38.675,-9.17],["Praia do Ribatejo",39.467,-8.35],["Prior Velho",38.792,-9.121],["Proença-a-Nova",39.752,-7.924],["Quarteira",37.069,-8.101],["Queijas",38.719,-9.263],["Queluz",38.757,-9.255],["Quinta do Anjo",38.568,-8.942],["Quinta Do Conde",38.565,-9.043],["Ramada",38.804,-9.188],["Real",41.558,-8.443],["Rebordões",41.355,-8.424],["Rebordosa",41.224,-8.407],["Recarei",41.154,-8.412],["Redondo",38.649,-7.547],["Refojos de Basto",41.513,-7.995],["Reguengo",39.298,-7.392],["Reguengos de Monsaraz",38.425,-7.535],["Rendufe",41.629,-8.409],["Resende",41.106,-7.966],["Riachos",39.445,-8.514],["Riba de Ave",41.396,-8.387],["Ribeira de Pena",41.521,-7.802],["Ribeirão",41.361,-8.568],["Rio de Loba",40.666,-7.878],["Rio de Mouro",38.766,-9.328],["Rio Maior",39.337,-8.939],["Rio Mau",41.404,-8.68],["Rio Meão",40.958,-8.578],["Rio Tinto",41.179,-8.56],["Ronfe",41.441,-8.384],["Rosairinho",38.677,-9.008],["Sabrosa",41.267,-7.576],["Sabugal",40.351,-7.091],["Sacavém",38.792,-9.108],["Sagres",37.009,-8.943],["Salir de Matos",39.432,-9.095],["Salreu",40.74,-8.557],["Salvada",37.938,-7.774],["Salvaterra de Magos",39.028,-8.793],["Samil",41.776,-6.757],["Samora Correia",38.937,-8.872],["Samouco",38.72,-9.005],["Sande",41.702,-8.392],["Sandim",41.035,-8.507],["Sanfins",40.93,-8.526],["Sangalhos",40.487,-8.47],["Santa Bárbara de Nexe",37.106,-7.966],["Santa Catarina da Serra",39.68,-8.687],["Santa Clara",40.2,-8.44],["Santa Comba Dão",40.399,-8.132],["Santa Cruz",41.76,-7.468],["Santa Cruz do Bispo",41.215,-8.674],["Santa Iria da Azóia",38.841,-9.099],["Santa Luzia",37.102,-7.662],["Santa Margarida da Coutada",39.45,-8.317],["Santa Marta de Penaguião",41.21,-7.784],["Santarém",39.233,-8.683],["Santiago do Cacém",38.017,-8.695],["Santo André",39.055,-8.244],["Santo Antão do Tojal",38.852,-9.14],["Santo António da Charneca",38.626,-9.03],["Santo António dos Olivais",40.218,-8.405],["Santo Isidoro",38.996,-9.399],["Santo Izidoro",41.211,-8.142],["Santo Tirso",41.343,-8.477],["Santos-o-Velho",38.707,-9.156],["São Bartolomeu",39.275,-9.279],["São Bartolomeu de Messines",37.256,-8.287],["São Brás de Alportel",37.153,-7.888],["São Domingos de Rana",38.702,-9.341],["São Félix da Marinha",41.036,-8.623],["São João",40.868,-8.607],["São João da Madeira",40.901,-8.49],["São João da Pesqueira",41.148,-7.405],["São João da Talha",38.824,-9.097],["São João das Lampas",38.874,-9.398],["São João de Areias",40.387,-8.068],["São João de Ver",40.955,-8.551],["São João dos Montes",38.939,-9.019],["São Julião",39.323,-7.311],["São Luis",37.716,-8.665],["São Mamede de Infesta",41.192,-8.611],["São Marcos da Serra",37.361,-8.378],["São Martinho do Porto",39.514,-9.131],["São Miguel de Rio Torto",39.433,-8.217],["São Miguel do Couto",41.332,-8.462],["São Pedro da Cadeira",39.07,-9.372],["São Pedro da Cova",41.143,-8.5],["São Pedro de Alva",40.3,-8.166],["São Pedro do Sul",40.755,-8.073],["São Romão",40.401,-7.715],["São Romão do Coronado",41.285,-8.563],["São Roque",40.872,-8.471],["São Teotónio",37.513,-8.707],["São Vicente do Paul",39.349,-8.622],["Sardoal",39.534,-8.161],["Sarilhos Pequenos",38.682,-8.982],["Sátão",40.742,-7.733],["Seia",40.415,-7.709],["Seixal",38.64,-9.101],["Selho",41.419,-8.346],["Semelhe",41.554,-8.463],["Sendim",41.387,-6.426],["Senhora da Hora",41.186,-8.652],["Senhora da Luz",37.088,-8.726],["Sequeira",40.554,-7.226],["Sermonde",41.047,-8.584],["Sernancelhe",40.899,-7.493],["Seroa",41.265,-8.429],["Serpa",37.946,-7.598],["Serra de El-Rei",39.333,-9.268],["Sertã",39.802,-8.096],["Serzedelo",41.401,-8.369],["Serzedo",41.405,-8.229],["Sesimbra",38.445,-9.101],["Setúbal",38.524,-8.888],["Sever do Vouga",40.735,-8.367],["Silvalde",40.992,-8.626],["Silveira",39.111,-9.364],["Silves",37.189,-8.438],["Sines",37.956,-8.87],["Sintra",38.801,-9.378],["Sobrado",41.21,-8.455],["Sobral de Monte Agraço",39.02,-9.151],["Sobralinho",38.917,-9.027],["Sobreda",38.65,-9.19],["Sobreira",41.524,-7.802],["Soure",40.06,-8.626],["Souto",40.985,-8.622],["Souto da Carpalhosa",39.849,-8.835],["Tábua",40.362,-8.029],["Tabuaço",41.116,-7.568],["Tarouca",41.018,-7.775],["Tavarede",40.167,-8.846],["Tavira",37.127,-7.649],["Tebosa",41.483,-8.484],["Teixoso",40.314,-7.458],["Telões",41.311,-8.111],["Terras de Bouro",41.718,-8.309],["Terrugem",38.706,-9.287],["Tocha",40.313,-8.753],["Tomar",39.602,-8.409],["Tondela",40.517,-8.081],["Torre de Moncorvo",41.175,-7.054],["Torres Novas",39.476,-8.543],["Torres Vedras",39.091,-9.259],["Trafaria",38.672,-9.233],["Tramagal",39.45,-8.25],["Trancoso",40.783,-7.35],["Travanca",40.324,-8.187],["Treixedo",40.432,-8.094],["Trofa",41.337,-8.56],["Tunes",37.166,-8.259],["Turquel",39.464,-8.977],["Unhos",38.82,-9.12],["Urgeses",41.427,-8.298],["Urra",39.228,-7.399],["Vagos",40.556,-8.682],["Vairão",41.333,-8.667],["Valadares",41.147,-7.981],["Valado de Frades",39.584,-9.023],["Valbom",41.129,-8.562],["Vale da Amoreira",39.07,-7.698],["Vale de Cambra",40.85,-8.394],["Vale de Figueira",39.306,-8.629],["Vale de Santarém",39.191,-8.727],["Válega",40.836,-8.581],["Valença",42.031,-8.646],["Valenza",42.024,-8.635],["Valongo",41.189,-8.499],["Valpaços",41.607,-7.311],["Várzea",41.515,-8.584],["Venda do Pinheiro",38.924,-9.232],["Vendas Novas",38.677,-8.458],["Ventosa",39.127,-9.084],["Vestiaria",39.553,-8.998],["Vialonga",38.872,-9.078],["Viana do Alentejo",38.335,-8.004],["Viana do Castelo",41.693,-8.833],["Vidais",39.369,-9.049],["Vidigueira",38.21,-7.801],["Vieira de Leiria",39.869,-8.932],["Vieira do Minho",41.633,-8.143],["Vila",42.03,-8.159],["Vila Chã",40.867,-8.467],["Vila Chã de Ourique",39.172,-8.767],["Vila Cova",41.551,-8.716],["Vila de Rei",39.676,-8.146],["Vila do Bispo",37.083,-8.911],["Vila do Conde",41.353,-8.745],["Vila Flor",41.309,-7.154],["Vila Franca de Xira",38.955,-8.99],["Vila Frescainha",41.538,-8.64],["Vila Meã",41.251,-8.184],["Vila Nova da Barquinha",39.461,-8.436],["Vila Nova da Telha",41.072,-8.641],["Vila Nova De Cacela",37.174,-7.532],["Vila Nova de Cerveira",41.941,-8.742],["Vila Nova de Famalicão",41.408,-8.52],["Vila Nova de Foz Côa",41.082,-7.141],["Vila Nova de Gaia",41.124,-8.612],["Vila Nova de Milfontes",37.724,-8.783],["Vila Nova de Paiva",40.853,-7.728],["Vila Pouca de Aguiar",41.5,-7.644],["Vila Praia de Âncora",41.811,-8.853],["Vila Real",41.301,-7.744],["Vila Real de Santo António",37.195,-7.418],["Vila Seca",41.5,-8.685],["Vila Velha de Ródão",39.656,-7.677],["Vila Verde",39.155,-9.115],["Vila Viçosa",38.778,-7.418],["Vilaça",41.518,-8.484],["Vilamoura",37.087,-8.117],["Vilar de Andorinho",41.106,-8.586],["Vilar de Figos",41.476,-8.654],["Vilar do Paraíso",41.09,-8.621],["Vilarinho",41.36,-8.331],["Vilela",41.225,-7.603],["Vimeiro",39.178,-9.317],["Vimioso",41.585,-6.528],["Vinhais",41.835,-7.005],["Viseu",40.661,-7.91],["Vizela",41.391,-8.264],["Vouzela",40.724,-8.113],["Zambujeira do Mar",37.528,-8.785]];
var BASE = [39.917, -8.628]; // Pombal
var FATOR_ESTRADA = 1.25; // linha reta -> estrada (estimativa)
var semAcento = function (s) { return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); };
var INDICE = {};
LOCAIS.forEach(function (l) { INDICE[semAcento(l[0])] = l; });
document.getElementById('locais').innerHTML = LOCAIS.map(function (l) { return '<option value="' + l[0] + '">'; }).join('');
function kmIdaVolta(l) {
  var r = Math.PI / 180, dLa = (l[1] - BASE[0]) * r, dLo = (l[2] - BASE[1]) * r;
  var a = Math.pow(Math.sin(dLa / 2), 2) + Math.cos(BASE[0] * r) * Math.cos(l[1] * r) * Math.pow(Math.sin(dLo / 2), 2);
  return Math.round(2 * 6371 * 2 * Math.asin(Math.sqrt(a)) * FATOR_ESTRADA);
}
var ESTADO = {};
var eur = function (v) { return v.toLocaleString('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'; };
function simular() {
  var area = parseFloat(document.getElementById('area').value);
  var txt = semAcento(document.getElementById('local').value), loc = INDICE[txt];
  var km = loc ? kmIdaVolta(loc) : null;
  var linhas = document.querySelectorAll('#escaloes tr');
  var idx = -1, preco = null;
  if (area > 0) {
    idx = ESCALOES.length;
    for (var i = 0; i < ESCALOES.length; i++) { if (area <= ESCALOES[i][0]) { idx = i; preco = ESCALOES[i][1]; break; } }
  }
  linhas.forEach(function (tr, i) { tr.classList.toggle('activa', i === idx); });
  var des = km === null ? null : km * PRECO_KM;
  document.getElementById('r-des-rot').textContent = km === null ? 'Deslocação' : 'Deslocação (cerca de ' + km + ' km, ida e volta)';
  document.getElementById('r-des').textContent = des === null ? '—' : eur(des);
  ESTADO = { area: area, local: loc ? loc[0] : document.getElementById('local').value.trim(), km: km, preco: preco, des: des, idx: idx };
  var nota = document.getElementById('r-nota');
  if (idx === -1) {
    document.getElementById('r-lev').textContent = '—';
    document.getElementById('r-tot').textContent = '—';
    nota.textContent = 'Indique a área do terreno em metros quadrados.';
  } else if (preco === null) {
    document.getElementById('r-lev').textContent = 'Sob consulta';
    document.getElementById('r-tot').textContent = 'Sob consulta';
    nota.textContent = 'Para terrenos acima de 10 000 m² o preço é dado caso a caso. Contacte-nos.';
  } else if (des === null) {
    document.getElementById('r-lev').textContent = eur(preco);
    document.getElementById('r-tot').textContent = '—';
    nota.textContent = txt ? 'Não encontrámos essa localidade. Escolha uma da lista ou contacte-nos para calcular a deslocação.' : 'Indique a localidade do terreno para calcular a deslocação.';
  } else {
    document.getElementById('r-lev').textContent = eur(preco);
    document.getElementById('r-tot').textContent = eur(preco + des);
    nota.textContent = 'Distância estimada a partir de Pombal. O orçamento final é confirmado por contacto.';
  }
}
document.getElementById('simulador').addEventListener('input', function () { simular(); atualizarPedido(); });

// ---- Pedido de orçamento por email ----
var EMAIL_DESTINO = 'jvasco.marreiros@gmail.com';
var WHATSAPP = '351915457476';
// Endereço da aplicação web do Google Sheets (termina em /exec). Vazio = envio automático desligado.
var URL_PEDIDOS = '';
function campo(id) { return document.getElementById(id).value.trim(); }
function textoPedido() {
  var e = ESTADO, l = [];
  l.push('Pedido de orçamento de levantamento topográfico', '');
  l.push('TERRENO');
  l.push('Área: ' + (e.area > 0 ? e.area.toLocaleString('pt-PT') + ' m²' : 'por indicar'));
  l.push('Localidade: ' + (e.local || 'por indicar'));
  l.push('', 'SIMULAÇÃO NO SITE');
  l.push('Levantamento: ' + (e.idx === -1 ? 'por calcular' : e.preco === null ? 'sob consulta' : eur(e.preco)));
  l.push('Deslocação: ' + (e.des === null ? 'por calcular' : eur(e.des) + ' (cerca de ' + e.km + ' km, ida e volta desde Pombal)'));
  l.push('Total: ' + (e.idx === -1 || e.des === null ? 'por calcular' : e.preco === null ? 'sob consulta' : eur(e.preco + e.des)));
  l.push('', 'CLIENTE');
  l.push('Nome: ' + (campo('p-nome') + ' ' + campo('p-apelido')).trim());
  if (campo('p-tel')) l.push('Telemóvel: ' + campo('p-tel'));
  if (campo('p-email')) l.push('Email: ' + campo('p-email'));
  if (campo('p-empresa') || campo('p-nif') || campo('p-morada')) {
    l.push('', 'EMPRESA');
    if (campo('p-empresa')) l.push('Nome: ' + campo('p-empresa'));
    if (campo('p-nif')) l.push('NIF: ' + campo('p-nif'));
    if (campo('p-morada')) l.push('Morada: ' + campo('p-morada'));
  }
  return l.join('\n');
}
function erroPedido() {
  if (!campo('p-nome') || !campo('p-apelido')) return 'Indique o nome e o apelido.';
  if (!campo('p-tel') && !campo('p-email')) return 'Indique o telemóvel ou o email para o podermos contactar.';
  if (campo('p-email') && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(campo('p-email'))) return 'O email não parece estar correto.';
  if (campo('p-tel') && campo('p-tel').replace(/\D/g, '').length < 9) return 'O número de telemóvel deve ter pelo menos 9 algarismos.';
  if (campo('p-nif') && !/^\d{9}$/.test(campo('p-nif'))) return 'O NIF deve ter 9 algarismos.';
  return '';
}
function atualizarPedido() {
  var assunto = 'Pedido de orçamento' + (campo('p-nome') ? ' - ' + (campo('p-nome') + ' ' + campo('p-apelido')).trim() : '') + (ESTADO.local ? ' - ' + ESTADO.local : '');
  document.getElementById('p-whats').href = 'https://wa.me/' + WHATSAPP + '?text=' + encodeURIComponent(textoPedido());
  document.getElementById('p-enviar').href = 'mailto:' + EMAIL_DESTINO + '?subject=' + encodeURIComponent(assunto) + '&body=' + encodeURIComponent(textoPedido().replace(/\n/g, '\r\n'));
}
document.getElementById('p-enviar').addEventListener('click', function (ev) {
  var erro = erroPedido(), aviso = document.getElementById('p-aviso');
  if (erro) { ev.preventDefault(); aviso.textContent = erro; return; }
  atualizarPedido();
  aviso.textContent = 'O pedido abre no seu programa de email, já preenchido. Carregue em Enviar para o concluir. Se não abrir, copie o texto e envie para ' + EMAIL_DESTINO + '.';
});
document.getElementById('p-whats').addEventListener('click', function (ev) {
  var erro = erroPedido(), aviso = document.getElementById('p-aviso');
  if (erro) { ev.preventDefault(); aviso.textContent = erro; return; }
  atualizarPedido();
  aviso.textContent = 'O pedido abre no WhatsApp, já escrito. Carregue em enviar para o concluir.';
});
// ---- Envio automático do pedido para a folha de cálculo ----
(function () {
  var b = document.getElementById('p-auto'), aviso = document.getElementById('p-aviso');
  if (!URL_PEDIDOS) return;
  b.hidden = false;
  document.getElementById('p-enviar').className = 'botao linha';
  b.addEventListener('click', function () {
    var erro = erroPedido();
    if (erro) { aviso.textContent = erro; return; }
    if (ESTADO.idx === -1 || !ESTADO.local) { aviso.textContent = 'Indique a área e a localidade do terreno no simulador.'; return; }
    var dados = { nome: campo('p-nome'), apelido: campo('p-apelido'), telemovel: campo('p-tel'), email: campo('p-email'),
      empresa: campo('p-empresa'), nif: campo('p-nif'), morada: campo('p-morada'), website: campo('p-website'),
      area: ESTADO.area, localidade: ESTADO.local, km: ESTADO.km, levantamento: ESTADO.preco, deslocacao: ESTADO.des };
    b.disabled = true; b.textContent = 'A enviar...'; aviso.textContent = '';
    // text/plain evita o pedido prévio de permissões que o Google Apps Script não aceita
    fetch(URL_PEDIDOS, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(dados) })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (!r.ok) throw new Error(r.erro || 'erro');
        b.textContent = 'Pedido enviado';
        aviso.textContent = 'Pedido enviado. ' + (campo('p-email') ? 'Vai receber a confirmação por email e, em breve, o orçamento.' : 'Entraremos em contacto pelo telemóvel indicado.');
      })
      .catch(function () {
        b.disabled = false; b.textContent = 'Enviar pedido de orçamento';
        aviso.textContent = 'Não foi possível enviar o pedido. Tente de novo ou use o email ou o WhatsApp.';
      });
  });
})();
document.getElementById('p-copiar').addEventListener('click', function () {
  var aviso = document.getElementById('p-aviso'), erro = erroPedido();
  if (erro) { aviso.textContent = erro; return; }
  var ok = function () { aviso.textContent = 'Texto copiado. Cole-o num email para ' + EMAIL_DESTINO + '.'; };
  var falhou = function () { aviso.textContent = 'Não foi possível copiar. Envie os dados para ' + EMAIL_DESTINO + '.'; };
  try { navigator.clipboard.writeText(textoPedido()).then(ok, falhou); } catch (e) { falhou(); }
});
document.getElementById('simulador').addEventListener('submit', function (e) { e.preventDefault(); });
// ---- Menu em ecrãs pequenos e barra superior ----
(function () {
  var b = document.getElementById('menu-btn'), m = document.getElementById('menu'), topo = document.getElementById('topo');
  function abrir(a) { m.classList.toggle('aberto', a); topo.classList.toggle('menu-aberto', a); b.setAttribute('aria-expanded', a); b.setAttribute('aria-label', a ? 'Fechar menu' : 'Abrir menu'); }
  b.addEventListener('click', function () { abrir(!m.classList.contains('aberto')); });
  m.addEventListener('click', function (e) { if (e.target.tagName === 'A') abrir(false); });
  function rolar() { topo.classList.toggle('rolado', window.scrollY > 10); }
  window.addEventListener('scroll', rolar, { passive: true }); rolar();
})();
simular();
atualizarPedido();
document.getElementById('ano').textContent = new Date().getFullYear();

// ---- Curvas de nível em SVG vetorial, que se deformam ao deslizar a página ----
(function () {
  var NS = 'http://www.w3.org/2000/svg', lista = [].slice.call(document.querySelectorAll('svg.curvas'));
  var seed = 7; function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
  var G = 12, grid = []; for (var i = 0; i < G * G; i++) grid.push(rnd());
  function ruido(x, y) {
    var xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
    var sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    var g = function (a, b) { return grid[((b % G + G) % G) * G + ((a % G + G) % G)]; };
    var t = g(xi, yi) + (g(xi + 1, yi) - g(xi, yi)) * sx, b = g(xi, yi + 1) + (g(xi + 1, yi + 1) - g(xi, yi + 1)) * sx;
    return t + (b - t) * sy;
  }
  // duas camadas de relevo que deslizam em sentidos diferentes: as curvas mudam de forma com o tempo t
  function altura(x, y, t) { return ruido(x * 2.1 + t * .55, y * 2.1 + t * .2) * .7 + ruido(x * 5.3 + 3 - t * .35, y * 5.3 + 1 + t * .45) * .3; }
  function el(nome, attrs) { var e = document.createElementNS(NS, nome); for (var k in attrs) e.setAttribute(k, attrs[k]); return e; }
  var r1 = function (n) { return Math.round(n * 10) / 10; };
  var reduz = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function desenhar(svg, t, comCotas) {
    var caixa = svg.getBoundingClientRect(), w = Math.round(caixa.width), h = Math.round(caixa.height);
    if (!w || !h) return;
    var dx = parseFloat(svg.getAttribute('data-desloc')) || 0;
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var desl = reduz ? 0 : window.scrollY * .5;
    var s = 10, cols = Math.ceil(w / s) + 1, rows = Math.ceil(h / s) + 1, v = [], k = 1 / 620;
    for (var j = 0; j < rows; j++) for (var i2 = 0; i2 < cols; i2++) v.push(altura(i2 * s * k + dx, (j * s + desl) * k, t));
    var N = 16, rotulos = [];
    for (var n = 1; n < N; n++) {
      var L = n / N, d = '', mestra = n % 4 === 0, segs = [];
      for (var y = 0; y < rows - 1; y++) for (var x = 0; x < cols - 1; x++) {
        var a = v[y * cols + x], b = v[y * cols + x + 1], c = v[(y + 1) * cols + x], e = v[(y + 1) * cols + x + 1];
        var p = [];
        if ((a < L) !== (b < L)) p.push([x + (L - a) / (b - a), y]);
        if ((b < L) !== (e < L)) p.push([x + 1, y + (L - b) / (e - b)]);
        if ((c < L) !== (e < L)) p.push([x + (L - c) / (e - c), y + 1]);
        if ((a < L) !== (c < L)) p.push([x, y + (L - a) / (c - a)]);
        for (var q = 0; q + 1 < p.length; q += 2) {
          var x1 = p[q][0] * s, y1 = p[q][1] * s, x2 = p[q + 1][0] * s, y2 = p[q + 1][1] * s;
          d += 'M' + r1(x1) + ' ' + r1(y1) + 'L' + r1(x2) + ' ' + r1(y2);
          if (mestra && comCotas) segs.push([x1, y1, x2, y2]);
        }
      }
      if (d) svg.appendChild(el('path', { d: d, fill: 'none', stroke: '#D4743B', 'stroke-opacity': mestra ? .85 : .45, 'stroke-width': mestra ? 1.4 : .9, 'stroke-linecap': 'round' }));
      for (var z = 3, postos = 0; z < segs.length && postos < 4; z += 7) {
        var m = segs[z], cx = (m[0] + m[2]) / 2, cy = (m[1] + m[3]) / 2;
        if (cx < w * .45 || cx > w - 40 || cy < 26 || cy > h - 26) continue;
        if (rotulos.some(function (o) { return Math.abs(o[0] - cx) + Math.abs(o[1] - cy) < 190; })) continue;
        var ang = Math.atan2(m[3] - m[1], m[2] - m[0]) * 180 / Math.PI; if (ang > 90) ang -= 180; if (ang < -90) ang += 180;
        rotulos.push([cx, cy, ang, 200 + n * 5]); postos++;
      }
    }
    rotulos.forEach(function (o) {
      var tx = el('text', { x: r1(o[0]), y: r1(o[1]), transform: 'rotate(' + r1(o[2]) + ' ' + r1(o[0]) + ' ' + r1(o[1]) + ')', 'text-anchor': 'middle', 'dominant-baseline': 'central', 'font-size': 10, 'font-weight': 500, 'font-family': 'Montserrat, sans-serif', fill: '#D4743B', stroke: '#08242B', 'stroke-width': 5, 'paint-order': 'stroke' });
      tx.textContent = o[3]; svg.appendChild(tx);
    });
  }
  function tempo() { return reduz ? 0 : window.scrollY / 1500; }
  function visivel(svg) { var r = svg.getBoundingClientRect(); return r.bottom > 0 && r.top < window.innerHeight; }
  function todas(comCotas, soVisiveis) {
    // forte na abertura, discreto por trás do resto da página
    var forte = window.innerWidth < 820 ? .5 : 1, fraco = window.innerWidth < 820 ? .2 : .34;
    var op = Math.max(fraco, forte - (forte - fraco) * window.scrollY / 380);
    lista.forEach(function (s) { s.style.opacity = op; });
    lista.forEach(function (s) { if (!soVisiveis || visivel(s)) desenhar(s, tempo(), comCotas); });
  }
  todas(true, false);
  var pedido = false, fim;
  if (!reduz) window.addEventListener('scroll', function () {
    if (!pedido) { pedido = true; requestAnimationFrame(function () { pedido = false; todas(false, true); }); }
    clearTimeout(fim); fim = setTimeout(function () { todas(true, false); }, 180);   // as cotas voltam quando a página pára
  }, { passive: true });
  var larg = window.innerWidth, tr;
  window.addEventListener('resize', function () { clearTimeout(tr); tr = setTimeout(function () { if (window.innerWidth !== larg) { larg = window.innerWidth; todas(true, false); } }, 150); });
})();

// ---- Aplicação web: funciona offline e pode ser instalada ----
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
}
(function () {
  var b = document.getElementById('instalar'), convite = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); convite = e; b.hidden = false; });
  b.addEventListener('click', function () { if (!convite) return; convite.prompt(); convite = null; b.hidden = true; });
  window.addEventListener('appinstalled', function () { b.hidden = true; });
})();
